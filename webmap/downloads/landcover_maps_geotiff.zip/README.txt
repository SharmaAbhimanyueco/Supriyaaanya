Land-cover maps, March 2015, 2020 and 2025 (GeoTIFF, EPSG:32643 / UTM 43N, 30 m pixels).
Codes: 1 Built-up, 2 Cropland, 3 Trees/vegetation, 5 Bare/fallow, 0 no data. Each .qml file is the QGIS style.
Licence: CC BY 4.0. Credit: Supriya Mahshere and Aanya Upadhyay (2026), Mapping urban growth in the Mohali-Kharar-Zirakpur-Dera Bassi belt. Landsat data courtesy of the U.S. Geological Survey.
