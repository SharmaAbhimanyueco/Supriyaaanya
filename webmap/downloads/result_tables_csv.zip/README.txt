Every result of the project as CSV tables (open in Excel or Google Sheets).
Licence: CC BY 4.0. Credit: Supriya Mahshere and Aanya Upadhyay (2026), Mapping urban growth in the Mohali-Kharar-Zirakpur-Dera Bassi belt. Landsat data courtesy of the U.S. Geological Survey.
